# Cowork ROI — Personal Impact Report (skill)

Generates a Microsoft-branded **"What Cowork Did for Me"** single-file HTML report from your own
Copilot Cowork session history in OneDrive. It leads with **research-anchored Time Saved** and its
**professional-services-equivalent Value**, then maps your work to your own Jobs, Business Processes,
and the four Value Pillars.

> **v15:** the expert clock is now purely research-anchored — Time Saved = the **sum of the cited
> per-task bands** (e.g. Analysis 67 + Document 24 = 91 min). The old read-time/authoring heuristics
> were removed; the speed multiplier is now a clearly-labelled secondary stat. See
> [`CHANGELOG-v15.md`](CHANGELOG-v15.md).

---

## Get Started in 4 Steps

1. **Download** `cowork-roi-report-skill-v15.zip`. *(No need to unzip — attach it as-is.)*
2. **Open** a new [Copilot Cowork](https://copilot.cloud.microsoft/cowork) session.
3. **Click the ➕ (plus) symbol** to attach the zip file, then send: **Add this skill.**
4. Once it's added, ask: **Generate my impact summary report.**

You'll be asked which period to measure (7, 15 or 30 days), then the report is built. That's it. 🎉

---

## Contents

```
cowork-roi-report/
├── SKILL.md                     # skill definition + workflow (loaded by Cowork)
├── README.md                    # this file
├── CHANGELOG-v15.md             # latest changes (+ v5/v6/v11/v13/v14 history)
├── scripts/
│   ├── classify.py              # deterministic classifier → inputs/outputs + tasks schema
│   ├── compute.py               # applies the methodology → payload JSON
│   ├── build_report.py          # renders the self-contained HTML report
│   ├── mine_session.py          # mines the live session transcript for real run-time (telemetry hook)
│   ├── statusline_cost.py       # captures real per-session cost (statusLine hook)
│   ├── apqc_taxonomy.json       # generic APQC fallback business-process taxonomy
│   └── skills_vocabulary.json   # controlled vocabulary for "skills augmented"
├── references/
│   ├── map-my-work-playbook.md  # derives your own Jobs ▸ Processes ▸ Workflows (run inline at step 4b)
│   └── value-pillars.md         # the four-pillar crosswalk
└── examples/
    └── sample_sessions.json     # synthetic input (safe to share)
```

`map-my-work` is **folded in** as a reference playbook — there is no second skill to install, and it
runs automatically when the report is generated.

---

## What's in the report

- **Hero** — research-anchored **Time Saved** (conservative / typical / optimistic) + **Value**
- **KPIs** — sessions, run tasks, deliverables, active days, expert-equivalent hours
- **Value at a glance** — the four Value Pillars with example KPIs
- **Work by business process** — every session mapped to *your own* Job ▸ Business Process, banded by
  **Job × Value Pillar** with a stakeholder **JTBD** line and an (auto-hiding) **session-cost** column
- **Where the time went — by task category** — research-anchored bands
- **Skills augmented** — controlled-vocabulary skills Cowork stood in for, with hours
- **Deliverables & the skills behind them**
- **Methodology & glossary** — every band traceable, with clickable research sources

## The four Value Pillars

| Pillar | Type | Example KPI |
|---|---|---|
| **Revenue Growth** | Tangible · money coming in | Incremental gross revenue |
| **Cost Reduction** | Tangible · money going out | Labor & budget savings |
| **Risk Mitigation** | Intangible · money going out | Penalties & losses avoided |
| **Transformation** | Intangible · money coming in | Adoption, decision quality, retention |

Each session's process, pillar, job, and JTBD are **derived at run time from your own footprint** —
nothing in this skill is specific to any individual. If the playbook isn't run, classification falls
back to a generic APQC taxonomy (Job = "Other").

---

## Methodology — research-anchored time saved

**Time Saved (expert-equivalent)** — what a professional would take with no AI — is simply the
**sum of the research-anchored band for each task** in a session. Nothing else: no read-time or
authoring assumptions, so every minute traces to a cited study.

```
time_saved_min = Σ CATS[task].typical        # e.g. Analysis (67) + Document (24) = 91 min
```

The **Conservative / Optimistic** range re-sums the published **low** / **high** band per task.

**Headline (both fully research-anchored):**

```
Time Saved (hours) = Σ time_saved_min / 60
Value              = Time Saved hours × hourly_rate
```

**Speed multiplier (secondary, directional).** Dividing Time Saved by a *modeled* hands-on clock
gives a speed multiplier. The assisted clock is the one non-research input — OneDrive can't measure
keystroke time — so the multiplier is directional, not a stopwatch (it is *measured* for sessions
where the telemetry hook is enabled):

```
assisted_min     = 8 (prompt/setup) + 2 × (num inputs + outputs)   ·  floor 4   [modeled]
speed_multiplier = Σ time_saved_min / Σ assisted_min               (rate-independent · secondary)
```

### Research-anchored category bands (min saved / task)

| Category | Low | **Typical** | High |
|---|---:|---:|---:|
| Analysis & Research | 30 | **67** | 92 |
| Document & content creation | 12 | **24** | 42 |
| Email workflows | 3 | **7** | 12 |
| Meeting workflows | 12 | **31** | 43 |
| Communication workflows | 2 | **4** | 11 |
| Specialized workflows | 10 | **25** | 40 |
| Write or debug code | 30 | **56** | 96 |
| General assistance / Other | 2 | **5** | 8 |

Full source citations (Stanford-WB, Microsoft Research, NBER, Forrester, etc.) are embedded in the
report's Glossary and in `build_report.py`.

---

## Optional hooks — capture cost & chat-only sessions automatically

Two `settings.json` hooks enrich the report over time (both forward-looking — they can't backfill
past sessions). Wire them once, then activate by opening `/hooks` or restarting:

- **statusLine → `statusline_cost.py`** logs each live session's real cost to
  `cowork-session-costs.json`, filling the session-cost column. (The column auto-hides when there's
  no cost data.)
- **Stop hook → `mine_session.py --log …cowork-session-telemetry.json`** records every session
  (run-time, tools, artifacts, `produced_artifact`) so **chat-only / folder-less sessions are
  counted**, not just those that saved a file.

Only the *live* session is minable, so the logs build forward as you use Cowork.

---

## Run the scripts directly (dev)

```bash
python scripts/classify.py     --in working/cowork_raw.json      --out working/cowork_sessions.json
python scripts/compute.py      --in working/cowork_sessions.json --out working/cowork_roi_data.json
python scripts/build_report.py --data working/cowork_roi_data.json --out output/cowork-roi-report.html
```

No third-party dependencies — standard-library Python 3 only.

### Input schema (`cowork_sessions.json`)

Each session carries `inputs`/`outputs` (each with `ext` and optional `skills`), `tasks` (category
keys), and — when the map-my-work playbook runs — `process`, `value_pillar`, `job`, and `jtbd`.
Task category keys: `analysis · document · email · meeting · comms · special · code · general`.

---

## Caveats (state these in any readout)

- **Time Saved & Value are research-anchored** (cited per-task bands). The **speed multiplier's**
  assisted clock is a **modeled** estimate (measured where the telemetry hook is on), so treat the
  multiplier as directional.
- Categories with **no tasks** in the window are reported as **zero**, keeping totals a conservative floor.
- Counting stays conservative: supporting files are folded into the primary task.
- Everything is **derived per user at run time** — nothing in the skill is specific to any individual.
