# Cowork ROI report skill — **v23** (standalone)

The **`cowork-roi-report`** skill on its own — generates the Microsoft-branded **"What Cowork Did for Me"**
HTML impact report from your signed-in Cowork session history. This is just the report skill (no member /
team-rollup skill, no bundle).

## v23 highlights
- **Process-anchored** "Work by business process": **Business Process ▸ JTBD ▸ Project** (the standalone
  Job layer was dropped), with an indented hierarchy and per-process subtotals (sessions · hours · value · % of time).
- **Durable taxonomy memory** — `scripts/reconcile_taxonomy.py` + a registry at
  `~/.claude/cowork-process-registry.json` that keeps Process/Project names stable across runs
  (align-first; only novel work mints a new entry). See `CHANGELOG-v23.md`.

## Install
1. Copy the **`cowork-roi-report/`** folder into your personal Cowork skills directory:
   - OneDrive: `Documents/Cowork/skills/`  (container: `~/.claude/skills/`)
2. **Seed the taxonomy memory (once):** copy `cowork-process-registry.seed.json` to
   `~/.claude/cowork-process-registry.json` — only if you don't already have one (don't overwrite a
   populated registry). Edit the processes/keywords to fit your work.

Then ask Cowork: **"generate my impact summary report."** Changes appear after OneDrive sync (~35s).

## Notes
- `scripts/process_overrides.json` ships **empty** — it's personal and is regenerated each run by
  `reconcile_taxonomy.py`. `process_overrides.example.json` shows the format.
- The seed registry ships with shared **processes** but **no projects** — projects populate from your
  own sessions. No personal data, file contents, or prompts are included in this zip.
