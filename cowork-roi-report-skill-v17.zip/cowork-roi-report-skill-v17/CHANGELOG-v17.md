# Cowork ROI Report — v17 (two-lens work-by-process)

## Work-by-business-process — redesigned into two lenses, one toggle
- **By Job-to-be-Done** — an indented **Job ▸ Business Process ▸ JTBD ▸ Project** hierarchy. Each
  level has a labeled chip (JOB / PROCESS / JTBD / PROJECTS). Under each process it now lists the
  **actual projects** Cowork delivered (not task categories), each with its assistance inline
  (expert-equivalent hours saved · value · speed).
- **By Business Value Pillar** — a simple 3-column table: **Business value pillar · Project ·
  Assistance offered** (pillar shown once per group).
- The toggle flips between the two; task-category rows are gone from this section.
- **"How to read this"** expanded to the full Job → Process → JTBD → Project explanation
  ("why your role exists", the repeatable machine, the JTBD it's hired for, value flows up).

## Carried over from v16
- Professional roles "a billing firm would charge" (LLM-tagged + 16-role keyword fallback, ported
  from microsoft/What-I-Did-Copilot), each linked to a job search.
- Research-anchored Time Saved + Value hero; speed multiplier secondary; four value pillars; single
  self-contained skill; map-my-work folded in; auto-hiding cost column; chat-only sessions counted.
